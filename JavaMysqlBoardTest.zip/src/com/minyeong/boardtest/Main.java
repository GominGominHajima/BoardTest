package com.minyeong.boardtest;

public class Main {

	public static void main(String[] args) {
		ProcBoard procBoard = new ProcBoard();
		procBoard.run();
	}

}
